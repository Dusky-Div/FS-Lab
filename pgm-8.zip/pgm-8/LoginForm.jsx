const React = require("react");
const { useState } = React;
const LoginForm = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const validatePassword = (password) => {
    if (password.length < 8) return false;

    let hasUpperCase = false;
    let hasLowerCase = false;
    let hasNumber = false;
    let hasSpecialChar = false;
    const specialChars = "@$!%*?&";

    for (let char of password) {
      if (char >= "A" && char <= "Z") hasUpperCase = true;
      else if (char >= "a" && char <= "z") hasLowerCase = true;
      else if (char >= "0" && char <= "9") hasNumber = true;
      else if (specialChars.includes(char)) hasSpecialChar = true;
    }

    return hasLowerCase && hasUpperCase && hasNumber && hasSpecialChar;
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validatePassword(password)) {
      setMessage(
        "Password must be at least 8 characters long and include uppercase, lowercase, number,and special character."
      );
    } else {
      setMessage("Login successful (dummy validation).");
    }
  };
  return (
    <div style={{ maxWidth: "400px", margin: "50px auto" }}>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Email:</label>
          <br />
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <br />
        <div>
          <label>Password:</label>
          <br />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <br />
        <button type="submit">Login</button>
      </form>
      <p style={{ color: "red" }}>{message}</p>
    </div>
  );
};
export default LoginForm;
