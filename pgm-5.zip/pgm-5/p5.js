function getPrimeFactors(n) {
  const factors = [];
  while (n % 2 === 0) {
    factors.push(2);
    n = n / 2;
    for (let i = 3; i <= Math.sqrt(n); i += 2) {
      while (n % i === 0) {
        factors.push(i);
        n = n / i;
      }
    }
  }
  if (n > 2) {
    factors.push(n);
  }
  return factors;
}
document.getElementById("calculateBtn").addEventListener("click", () => {
  const input = document.getElementById("numberInput");
  const res = document.getElementById("result");
  const number = parseInt(input.value);
  res.className = "";
  if (isNaN(number) || number < 1) {
    res.textContent = "Please enter a valid positive integer";
    return;
  }
  const factors = getPrimeFactors(number);
  if (factors.length === 0) {
    res.textContent = "No prime factors found";
  } else {
    res.textContent = `Prime factors of ${number}: ${factors.join(" × ")}`;
  }
});
